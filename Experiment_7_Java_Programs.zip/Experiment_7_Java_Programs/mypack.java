package mypack;

public class Calculator {
    public void add(int a, int b) {
        System.out.println("Sum = " + (a + b));
    }
}