EXPERIMENT 1 - JAVA PROGRAMS

Files:
1.1 - test1.java
1.2 - test2.java
1.3 - test3.java
1.4 - test4.java
1.5 - test5.java

Compile a program:
    javac test1.java

Run programs that take keyboard input:
    java test2

Run test1 with two command-line arguments:
    java test1 Hello World

The public/main class name matches each Java filename.
